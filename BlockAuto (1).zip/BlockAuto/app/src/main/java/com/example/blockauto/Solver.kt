package com.example.blockauto

/**
 * Bộ giải cho game xếp khối kiểu "Block Blast" / "1010!" trên lưới 9x9.
 *
 * Ý tưởng:
 *  - Có 3 khối cần đặt hết lên bàn cờ, theo BẤT KỲ thứ tự nào (thử cả 6 hoán vị).
 *  - Sau mỗi lần đặt 1 khối, hàng/cột nào đầy sẽ được xoá ngay (giống game thật).
 *  - Duyệt toàn bộ tổ hợp (thứ tự x vị trí) khả thi, chấm điểm trạng thái bàn cờ cuối cùng,
 *    chọn tổ hợp có điểm cao nhất.
 *
 * Hàm số chấm điểm (heuristic) là phần "thông minh" — có thể tinh chỉnh trọng số ở dưới.
 */
object Solver {

    // Trọng số heuristic — chỉnh ở đây nếu muốn solver chơi "khôn" khác đi.
    private const val WEIGHT_LINE_CLEAR = 1000.0
    private const val WEIGHT_HOLE_PENALTY = 35.0      // ô bị vây kín 4 hướng, gần như không dùng được nữa
    private const val WEIGHT_EMPTY_BONUS = 1.0        // càng nhiều ô trống càng linh hoạt
    private const val WEIGHT_EDGE_BONUS = 0.5         // ưu tiên đặt sát mép/góc, giữ giữa bàn thoáng

    private val ROW_MASKS: Array<Board> = Array(BOARD_SIZE) { r ->
        var b = Board.EMPTY
        for (c in 0 until BOARD_SIZE) b = b.set(r, c)
        b
    }
    private val COL_MASKS: Array<Board> = Array(BOARD_SIZE) { c ->
        var b = Board.EMPTY
        for (r in 0 until BOARD_SIZE) b = b.set(r, c)
        b
    }

    private fun containsAll(board: Board, mask: Board): Boolean =
        (board.lo and mask.lo) == mask.lo && (board.hi and mask.hi) == mask.hi

    private fun subtract(board: Board, mask: Board): Board =
        Board(board.lo and mask.lo.inv(), board.hi and mask.hi.inv())

    /** Xoá các hàng/cột đầy. Trả về (bàn cờ mới, số dòng đã xoá). */
    private fun clearLines(board: Board): Pair<Board, Int> {
        var result = board
        var cleared = 0
        for (mask in ROW_MASKS) if (containsAll(board, mask)) { result = subtract(result, mask); cleared++ }
        for (mask in COL_MASKS) if (containsAll(board, mask)) { result = subtract(result, mask); cleared++ }
        return result to cleared
    }

    /** Thử đặt piece với ô neo tại (row,col). Trả về bàn cờ mới nếu hợp lệ, null nếu không. */
    private fun tryPlace(board: Board, piece: Piece, row: Int, col: Int): Board? {
        var result = board
        for ((dr, dc) in piece.cells) {
            val r = row + dr
            val c = col + dc
            if (r !in 0 until BOARD_SIZE || c !in 0 until BOARD_SIZE) return null
            if (result.isSet(r, c)) return null
            result = result.set(r, c)
        }
        return result
    }

    /** Đếm số ô trống bị vây kín cả 4 hướng (biên coi như "chắn") — gần như chỉ dùng được cho khối 1 ô. */
    private fun countSealedHoles(board: Board): Int {
        var holes = 0
        for (r in 0 until BOARD_SIZE) for (c in 0 until BOARD_SIZE) {
            if (board.isSet(r, c)) continue
            val up = r == 0 || board.isSet(r - 1, c)
            val down = r == BOARD_SIZE - 1 || board.isSet(r + 1, c)
            val left = c == 0 || board.isSet(r, c - 1)
            val right = c == BOARD_SIZE - 1 || board.isSet(r, c + 1)
            if (up && down && left && right) holes++
        }
        return holes
    }

    private fun edgeBonusFor(piece: Piece, row: Int, col: Int): Double {
        var bonus = 0.0
        for ((dr, dc) in piece.cells) {
            val r = row + dr
            val c = col + dc
            if (r == 0 || r == BOARD_SIZE - 1) bonus += WEIGHT_EDGE_BONUS
            if (c == 0 || c == BOARD_SIZE - 1) bonus += WEIGHT_EDGE_BONUS
        }
        return bonus
    }

    private fun scoreBoard(board: Board, totalLinesCleared: Int, totalEdgeBonus: Double): Double {
        val holes = countSealedHoles(board)
        val empty = TOTAL_CELLS - board.popCount()
        return totalLinesCleared * WEIGHT_LINE_CLEAR -
                holes * WEIGHT_HOLE_PENALTY +
                empty * WEIGHT_EMPTY_BONUS +
                totalEdgeBonus
    }

    /**
     * Giải: thử mọi thứ tự đặt (permutation) của 3 khối và mọi vị trí hợp lệ.
     * Trả về null nếu không có tổ hợp nào đặt được cả 3 khối (bàn cờ sẽ thua nếu không đặt được).
     */
    fun solve(initialBoard: Board, pieces: List<Piece>): Solution? {
        require(pieces.size <= 3) { "Chỉ hỗ trợ tối đa 3 khối mỗi lượt" }
        var best: Solution? = null

        fun recurse(
            board: Board,
            remainingIdx: List<Int>,
            movesSoFar: List<Move>,
            linesSoFar: Int,
            edgeBonusSoFar: Double
        ) {
            if (remainingIdx.isEmpty()) {
                val s = scoreBoard(board, linesSoFar, edgeBonusSoFar)
                if (best == null || s > best!!.score) {
                    best = Solution(movesSoFar, s, linesSoFar)
                }
                return
            }
            for (idx in remainingIdx) {
                val piece = pieces[idx]
                val maxRow = BOARD_SIZE - piece.height
                val maxCol = BOARD_SIZE - piece.width
                if (maxRow < 0 || maxCol < 0) continue
                for (r in 0..maxRow) for (c in 0..maxCol) {
                    val placed = tryPlace(board, piece, r, c) ?: continue
                    val (cleared, lineCount) = clearLines(placed)
                    val nextRemaining = remainingIdx.filter { it != idx }
                    recurse(
                        cleared,
                        nextRemaining,
                        movesSoFar + Move(idx, r, c),
                        linesSoFar + lineCount,
                        edgeBonusSoFar + edgeBonusFor(piece, r, c)
                    )
                }
            }
        }

        recurse(initialBoard, pieces.indices.toList(), emptyList(), 0, 0.0)
        return best
    }
}
