package com.example.blockauto

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.PixelFormat
import android.hardware.HardwareBuffer
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import androidx.annotation.RequiresApi

/**
 * Service chính: định kỳ chụp màn hình, đọc trạng thái bàn cờ + 3 khối,
 * gọi Solver, rồi thực hiện thao tác kéo-thả từng khối vào vị trí đã chọn.
 *
 * LƯU Ý: takeScreenshot() yêu cầu Android 11 (API 30) trở lên.
 * Bạn PHẢI tự đặt giá trị Calibration đúng cho máy của mình (xem README).
 */
class BlockPuzzleAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "BlockAuto"
        @Volatile var isRunning = false
        @Volatile var calibration: Calibration? = null
        @Volatile var instance: BlockPuzzleAccessibilityService? = null
        private val LOOP_DELAY_MS = 900L // chờ animation xoá dòng / rơi khối trước khi chụp lại
    }

    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.i(TAG, "Accessibility service đã kết nối")
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance === this) instance = null
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Không cần xử lý sự kiện UI ở đây — vòng lặp chạy độc lập qua Handler.
    }

    override fun onInterrupt() {}

    fun startLoop() {
        if (isRunning) return
        isRunning = true
        handler.post(loopRunnable)
    }

    fun stopLoop() {
        isRunning = false
        handler.removeCallbacks(loopRunnable)
    }

    private val loopRunnable = object : Runnable {
        override fun run() {
            if (!isRunning) return
            try {
                step()
            } catch (e: Exception) {
                Log.e(TAG, "Lỗi trong vòng lặp", e)
            }
            if (isRunning) handler.postDelayed(this, LOOP_DELAY_MS)
        }
    }

    @RequiresApi(Build.VERSION_CODES.R)
    private fun step() {
        val cal = calibration ?: run {
            Log.w(TAG, "Chưa có calibration, dừng lại"); stopLoop(); return
        }

        takeScreenshot(
            android.view.Display.DEFAULT_DISPLAY,
            mainExecutor,
            object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    val bitmap = hardwareBufferToBitmap(result.hardwareBuffer) ?: return
                    handleScreenshot(bitmap, cal)
                    result.hardwareBuffer.close()
                }
                override fun onFailure(errorCode: Int) {
                    Log.w(TAG, "Chụp màn hình thất bại: $errorCode")
                }
            }
        )
    }

    private fun hardwareBufferToBitmap(buffer: HardwareBuffer): Bitmap? {
        return try {
            Bitmap.wrapHardwareBuffer(buffer, null)?.copy(Bitmap.Config.ARGB_8888, false)
        } catch (e: Exception) {
            Log.e(TAG, "Không đọc được HardwareBuffer", e); null
        }
    }

    private fun handleScreenshot(bitmap: Bitmap, cal: Calibration) {
        val board = ScreenAnalyzer.readBoard(bitmap, cal)
        val pieceSlots = ScreenAnalyzer.readAllPieces(bitmap, cal)

        // Chỉ solver các khối còn tồn tại trong khay (bỏ qua khay trống).
        val activeIndices = pieceSlots.indices.filter { pieceSlots[it] != null }
        if (activeIndices.isEmpty()) {
            Log.i(TAG, "Không có khối nào trong khay, chờ lượt tiếp theo"); return
        }
        val activePieces = activeIndices.map { pieceSlots[it]!! }

        val solution = Solver.solve(board, activePieces)
        if (solution == null) {
            Log.w(TAG, "Không tìm được nước đi hợp lệ — có thể ván đã thua"); stopLoop(); return
        }

        Log.i(TAG, "Giải xong: điểm=${solution.score}, dòng xoá=${solution.linesCleared}")
        executeMovesSequentially(solution.moves, activeIndices, cal, 0)
    }

    /** Thực hiện từng nước đi tuần tự, cách nhau đủ thời gian để animation kéo-thả hoàn tất. */
    private fun executeMovesSequentially(
        moves: List<Move>,
        activeIndices: List<Int>,
        cal: Calibration,
        i: Int
    ) {
        if (i >= moves.size) return
        val move = moves[i]
        val trayIndex = activeIndices[move.pieceIndex]
        val (fromX, fromY) = cal.trayCenters[trayIndex]
        val (toX, toY) = cal.cellCenter(move.row, move.col)

        dragGesture(fromX, fromY, toX, toY) {
            handler.postDelayed({ executeMovesSequentially(moves, activeIndices, cal, i + 1) }, 350)
        }
    }

    /** Giả lập thao tác kéo (long-press + drag + release) bằng dispatchGesture. */
    private fun dragGesture(x1: Int, y1: Int, x2: Int, y2: Int, onDone: () -> Unit) {
        val path = Path().apply {
            moveTo(x1.toFloat(), y1.toFloat())
            lineTo(x2.toFloat(), y2.toFloat())
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, 300)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                onDone()
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                Log.w(TAG, "Gesture bị huỷ")
                onDone()
            }
        }, null)
    }
}
