package com.example.blockauto

import android.graphics.Bitmap

/**
 * Toạ độ hiệu chỉnh (calibration) — TOẠ ĐỘ PIXEL trên ảnh chụp màn hình đầy đủ.
 * Bạn phải tự đo 1 lần cho máy/độ phân giải của mình (xem README mục "Hiệu chỉnh").
 *
 * gridLeft/gridTop: góc trên-trái của ô (0,0) trong lưới 9x9.
 * cellSize: kích thước 1 ô (px), lưới vuông nên dùng chung cho row/col.
 * trayCenters: toạ độ tâm của 3 khay chứa khối ở dưới màn hình.
 * traySampleSpan: bán kính vùng lấy mẫu quanh mỗi ô trong khay (để dò hình dạng khối).
 */
data class Calibration(
    val gridLeft: Int,
    val gridTop: Int,
    val cellSize: Int,
    val trayCenters: List<Pair<Int, Int>>, // 3 điểm, mỗi điểm là tâm khay khối
    val trayCellSize: Int,                 // kích thước 1 ô nhỏ trong hình khối ở khay
    val trayGridSpan: Int = 5              // khối tối đa được coi là vừa trong ô vuông trayGridSpan x trayGridSpan
) {
    /** Toạ độ pixel (x,y) trung tâm ô (row,col) trên lưới chính. */
    fun cellCenter(row: Int, col: Int): Pair<Int, Int> =
        (gridLeft + col * cellSize + cellSize / 2) to (gridTop + row * cellSize + cellSize / 2)
}

object ScreenAnalyzer {

    // Màu nền "ô trống" của lưới — MÀU MẶC ĐỊNH, nên tự lấy mẫu thật trong app calibration.
    // Nếu độ sáng pixel < ngưỡng này thì coi là nền tối (trống); ngược lại coi là có khối (đầy màu).
    private const val EMPTY_LUMA_THRESHOLD = 60

    private fun luma(pixel: Int): Int {
        val r = (pixel shr 16) and 0xFF
        val g = (pixel shr 8) and 0xFF
        val b = pixel and 0xFF
        return (r * 299 + g * 587 + b * 114) / 1000
    }

    private fun isFilledPixel(pixel: Int): Boolean {
        // Alpha thấp hoặc quá tối -> coi là ô trống (nền lưới tối màu như ảnh mẫu).
        val a = (pixel shr 24) and 0xFF
        if (a < 20) return false
        return luma(pixel) > EMPTY_LUMA_THRESHOLD
    }

    /** Đọc trạng thái lưới 9x9 từ ảnh chụp màn hình. */
    fun readBoard(bitmap: Bitmap, cal: Calibration): Board {
        var board = Board.EMPTY
        for (r in 0 until BOARD_SIZE) for (c in 0 until BOARD_SIZE) {
            val (x, y) = cal.cellCenter(r, c)
            if (x !in 0 until bitmap.width || y !in 0 until bitmap.height) continue
            if (isFilledPixel(bitmap.getPixel(x, y))) board = board.set(r, c)
        }
        return board
    }

    /**
     * Đọc hình dạng khối trong 1 khay, trả về null nếu khay trống (đã dùng hết khối đó lượt trước).
     * Quét 1 vùng vuông trayGridSpan x trayGridSpan quanh tâm khay, coi ô nào có màu là 1 ô của khối,
     * rồi CHUẨN HOÁ (normalize) về toạ độ tương đối bắt đầu từ (0,0).
     */
    fun readPieceFromTray(bitmap: Bitmap, cal: Calibration, trayIndex: Int): Piece? {
        val (cx, cy) = cal.trayCenters[trayIndex]
        val span = cal.trayGridSpan
        val half = span / 2
        val raw = mutableListOf<Pair<Int, Int>>()
        for (r in -half..half) for (c in -half..half) {
            val x = cx + c * cal.trayCellSize
            val y = cy + r * cal.trayCellSize
            if (x !in 0 until bitmap.width || y !in 0 until bitmap.height) continue
            if (isFilledPixel(bitmap.getPixel(x, y))) raw.add((r + half) to (c + half))
        }
        if (raw.isEmpty()) return null
        val minR = raw.minOf { it.first }
        val minC = raw.minOf { it.second }
        val normalized = raw.map { (it.first - minR) to (it.second - minC) }
        return Piece(normalized)
    }

    fun readAllPieces(bitmap: Bitmap, cal: Calibration): List<Piece?> =
        cal.trayCenters.indices.map { readPieceFromTray(bitmap, cal, it) }
}
