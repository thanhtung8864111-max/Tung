package com.example.blockauto

/**
 * Bàn cờ 9x9 được biểu diễn bằng 2 số Long (bitboard) để tính toán cực nhanh.
 * Ô (row, col) -> bit index = row*9+col (0..80).
 * lo chứa bit 0..62, hi chứa bit 63..80.
 */
const val BOARD_SIZE = 9
const val TOTAL_CELLS = BOARD_SIZE * BOARD_SIZE // 81

data class Board(val lo: Long, val hi: Long) {

    fun isSet(row: Int, col: Int): Boolean {
        val idx = row * BOARD_SIZE + col
        return if (idx < 63) (lo shr idx) and 1L == 1L
        else (hi shr (idx - 63)) and 1L == 1L
    }

    fun set(row: Int, col: Int): Board {
        val idx = row * BOARD_SIZE + col
        return if (idx < 63) Board(lo or (1L shl idx), hi)
        else Board(lo, hi or (1L shl (idx - 63)))
    }

    fun popCount(): Int = java.lang.Long.bitCount(lo) + java.lang.Long.bitCount(hi)

    companion object {
        val EMPTY = Board(0L, 0L)

        /** Dựng Board từ ma trận boolean[row][col], true = ô đã bị chiếm. */
        fun fromGrid(grid: Array<BooleanArray>): Board {
            var b = EMPTY
            for (r in 0 until BOARD_SIZE) for (c in 0 until BOARD_SIZE) {
                if (grid[r][c]) b = b.set(r, c)
            }
            return b
        }
    }
}

/**
 * Một khối, biểu diễn bằng danh sách toạ độ tương đối (row, col) tính từ ô neo (0,0).
 * Ví dụ khối chữ L 3 ô: [(0,0),(1,0),(1,1)]
 */
data class Piece(val cells: List<Pair<Int, Int>>) {
    val height: Int = (cells.maxOf { it.first } - cells.minOf { it.first }) + 1
    val width: Int = (cells.maxOf { it.second } - cells.minOf { it.second }) + 1
    val size: Int = cells.size

    companion object {
        /** Dựng Piece từ ma trận boolean nhỏ (đúng bounding box của khối, không có hàng/cột thừa). */
        fun fromShape(shape: Array<BooleanArray>): Piece {
            val cells = mutableListOf<Pair<Int, Int>>()
            for (r in shape.indices) for (c in shape[r].indices) {
                if (shape[r][c]) cells.add(r to c)
            }
            return Piece(cells)
        }
    }
}

/** Một nước đi: đặt piece thứ [pieceIndex] (trong danh sách 3 khối gốc) tại (row, col) neo trên bàn cờ. */
data class Move(val pieceIndex: Int, val row: Int, val col: Int)

/** Kết quả solver trả về: thứ tự các nước đi tối ưu cho 3 khối, và điểm số ước tính. */
data class Solution(val moves: List<Move>, val score: Double, val linesCleared: Int)
