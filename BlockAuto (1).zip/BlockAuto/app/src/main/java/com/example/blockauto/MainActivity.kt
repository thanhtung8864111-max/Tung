package com.example.blockauto

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * Màn hình chính: hướng dẫn bật Accessibility Service, nhập toạ độ hiệu chỉnh (calibration),
 * và bật/tắt vòng lặp tự động chơi.
 *
 * Calibration nhập dạng 1 dòng, các số cách nhau bởi dấu phẩy, theo thứ tự:
 * gridLeft,gridTop,cellSize,tray1X,tray2X,tray3X,trayY,trayCellSize
 *
 * Cách đo: mở game, chụp màn hình (Power+Volume down), mở ảnh trong app xem ảnh có hiện toạ độ
 * pixel khi zoom (hoặc dùng app đo pixel), rồi điền các giá trị:
 *  - gridLeft, gridTop: toạ độ pixel góc trên-trái của Ô (0,0) trong lưới 9x9.
 *  - cellSize: chiều rộng 1 ô lưới, tính bằng pixel.
 *  - tray1X, tray2X, tray3X: toạ độ X tâm của 3 khay chứa khối phía dưới.
 *  - trayY: toạ độ Y chung của 3 khay (thường cùng hàng).
 *  - trayCellSize: kích thước 1 ô nhỏ trong hình khối ở khay (thường nhỏ hơn cellSize).
 */
class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)

        findViewById<Button>(R.id.btnOpenSettings).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.btnCalibrate).setOnClickListener { showCalibrationDialog() }

        findViewById<Button>(R.id.btnStart).setOnClickListener {
            if (BlockPuzzleAccessibilityService.calibration == null) {
                Toast.makeText(this, "Hãy nhập toạ độ hiệu chỉnh trước", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            serviceInstance()?.startLoop()
            statusText.text = "Trạng thái: đang tự động chơi..."
        }

        findViewById<Button>(R.id.btnStop).setOnClickListener {
            serviceInstance()?.stopLoop()
            statusText.text = "Trạng thái: đã dừng"
        }
    }

    // Lấy instance service đang chạy — cần service đã được hệ thống bật (qua Accessibility settings).
    private fun serviceInstance(): BlockPuzzleAccessibilityService? {
        // Đơn giản hoá: dựa vào biến static isRunning/calibration trong companion object.
        // Cách chuẩn hơn là dùng LocalBroadcastManager hoặc bind service; để đơn giản ta gọi
        // trực tiếp qua một tham chiếu static được service tự gán khi onServiceConnected().
        return BlockPuzzleAccessibilityService.instance
    }

    private fun showCalibrationDialog() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT
            hint = "gridLeft,gridTop,cellSize,tray1X,tray2X,tray3X,trayY,trayCellSize"
        }
        AlertDialog.Builder(this)
            .setTitle("Nhập toạ độ hiệu chỉnh")
            .setView(input)
            .setPositiveButton("Lưu") { _, _ ->
                try {
                    val parts = input.text.toString().split(",").map { it.trim().toInt() }
                    require(parts.size == 8)
                    val (gridLeft, gridTop, cellSize, t1x, t2x, t3x, trayY, trayCellSize) =
                        Octuple(parts[0], parts[1], parts[2], parts[3], parts[4], parts[5], parts[6], parts[7])
                    BlockPuzzleAccessibilityService.calibration = Calibration(
                        gridLeft = gridLeft,
                        gridTop = gridTop,
                        cellSize = cellSize,
                        trayCenters = listOf(t1x to trayY, t2x to trayY, t3x to trayY),
                        trayCellSize = trayCellSize
                    )
                    Toast.makeText(this, "Đã lưu hiệu chỉnh", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "Sai định dạng, cần đúng 8 số cách nhau bởi dấu phẩy", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("Huỷ", null)
            .show()
    }
}

/** Helper tuple nhỏ vì Kotlin chuẩn chỉ có Pair/Triple. */
data class Octuple<A, B, C, D, E, F, G, H>(
    val a: A, val b: B, val c: C, val d: D, val e: E, val f: F, val g: G, val h: H
)
