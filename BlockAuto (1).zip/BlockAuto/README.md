# BlockAuto — App tự động chơi game xếp khối 9x9

## Kiến trúc
- `Solver.kt` — bộ giải: thử toàn bộ hoán vị thứ tự đặt 3 khối × mọi vị trí hợp lệ,
  chấm điểm theo số dòng xoá được, số ô "chết" (bị vây kín), số ô trống còn lại, và ưu tiên đặt sát mép.
  Đây là phần "não" — có thể tinh chỉnh trọng số ở đầu file để chơi khôn hơn.
- `BoardModels.kt` — biểu diễn bàn cờ bằng bitboard (2 số Long) để tính cực nhanh.
- `ScreenAnalyzer.kt` — đọc ảnh chụp màn hình, suy ra ô nào trống/đầy và hình dạng 3 khối trong khay.
- `BlockPuzzleAccessibilityService.kt` — vòng lặp: chụp màn hình → gọi Solver → giả lập kéo-thả
  bằng `dispatchGesture`. Không cần root, chỉ cần bật quyền Accessibility.
- `MainActivity.kt` — UI: mở cài đặt Accessibility, nhập toạ độ hiệu chỉnh, bật/tắt vòng lặp.

## Cách build

### Cách 1 — Có máy tính: dùng Android Studio
1. Mở thư mục `BlockAuto/` này bằng **Android Studio** (chọn "Open an existing project").
   Android Studio sẽ tự tạo Gradle wrapper còn thiếu — cứ để nó Sync.
2. Cắm điện thoại qua USB, bật **Tùy chọn nhà phát triển → Gỡ lỗi USB (USB debugging)**.
3. Nhấn Run ▶ để cài app lên máy (không cần root).

### Cách 2 — Chỉ có điện thoại: build bằng GitHub Actions (đám mây)
Không cần máy tính, không cần cài Android Studio. Làm hoàn toàn bằng trình duyệt trên điện thoại:

1. Tạo tài khoản tại **github.com** (miễn phí) nếu chưa có.
2. Tạo repository mới, đặt tên tuỳ ý (ví dụ `BlockAuto`), để **Public** hoặc **Private** đều được.
3. Vào repo vừa tạo, bấm **"Add file" → "Upload files"**, rồi tải lên **toàn bộ nội dung** thư mục
   `BlockAuto/` này (kéo thả cả cây thư mục — trình duyệt điện thoại vẫn hỗ trợ chọn nhiều file/thư mục
   từ trình quản lý file). File `.github/workflows/build.yml` PHẢI được giữ đúng đường dẫn.
4. Sau khi upload xong và commit, vào tab **"Actions"** ở đầu repo — workflow "Build APK" sẽ tự
   chạy (mất khoảng 3–5 phút). Nếu không tự chạy, bấm vào workflow rồi bấm **"Run workflow"**.
5. Khi chạy xong (dấu tick xanh), bấm vào lần chạy đó, kéo xuống mục **"Artifacts"**,
   tải file `BlockAuto-debug-apk` về — đây chính là file `.apk` để cài lên điện thoại.
6. Mở file `.apk` vừa tải bằng trình quản lý file trên điện thoại để cài đặt. Android sẽ hỏi
   "Cho phép cài từ nguồn không xác định" — bấm đồng ý (đây là bình thường vì app không phải từ
   Google Play).

## Cách hiệu chỉnh (calibration) — BẮT BUỘC trước khi chạy
Vì mỗi máy có độ phân giải/vị trí UI khác nhau, bạn cần đo 1 lần:
1. Mở game, chụp màn hình y hệt lúc bắt đầu lượt (đủ 3 khối trong khay).
2. Mở ảnh đó bằng công cụ đo pixel (ví dụ app "Pixel Ruler", hoặc mở ảnh trong máy tính bằng
   GIMP/Photoshop để xem toạ độ con trỏ).
3. Đo các giá trị:
   - `gridLeft, gridTop`: toạ độ pixel góc trên-trái của ô (0,0) trong lưới 9x9.
   - `cellSize`: bề rộng 1 ô lưới (px).
   - `tray1X, tray2X, tray3X`: toạ độ X tâm của 3 khối trong khay dưới màn hình.
   - `trayY`: toạ độ Y chung của khay (thường 3 khối cùng hàng).
   - `trayCellSize`: kích thước 1 ô nhỏ trong hình khối ở khay (nhỏ hơn `cellSize` của lưới chính).
4. Trong app, bấm "2. Nhập toạ độ hiệu chỉnh", nhập 8 số theo đúng thứ tự, cách nhau dấu phẩy:
   `gridLeft,gridTop,cellSize,tray1X,tray2X,tray3X,trayY,trayCellSize`

Nếu solver đọc sai bàn cờ (đặt khối chồng lên nhau, đi sai), thường là do calibration lệch
vài pixel — chỉnh lại `EMPTY_LUMA_THRESHOLD` trong `ScreenAnalyzer.kt` hoặc đo lại toạ độ.

## Chạy
1. Bấm "1. Mở cài đặt Accessibility" → tìm "BlockAuto" → bật lên.
2. Quay lại app, bấm "3. Bắt đầu tự động chơi".
3. Mở game lên, app sẽ tự chụp màn hình và chơi theo chu kỳ ~0.9s/lượt (chỉnh `LOOP_DELAY_MS`
   trong `BlockPuzzleAccessibilityService.kt` nếu game của bạn animation nhanh/chậm hơn).
4. Bấm "Dừng lại" để tắt.

## Giới hạn hiện tại / việc cần làm thêm
- `ScreenAnalyzer` dùng ngưỡng độ sáng đơn giản để phân biệt ô trống/đầy — nếu game có theme
  màu khác ảnh mẫu bạn gửi, cần chỉnh `EMPTY_LUMA_THRESHOLD`.
- Solver giả định bàn 9x9 và tối đa 3 khối/lượt — đúng với đa số game kiểu Block Blast/1010!.
- Chưa xử lý màn hình "Game Over" — khi solver không tìm được nước đi hợp lệ, vòng lặp tự dừng.

## Lưu ý rủi ro
Tự động hoá game gần như chắc chắn vi phạm điều khoản dịch vụ (ToS) của game. Nếu game có
kiểm tra hành vi bất thường, bảng xếp hạng, hoặc sự kiện có thưởng, tài khoản của bạn có thể
bị khoá hoặc bị reset điểm/thành tích. Dùng cho mục đích cá nhân, tự chịu rủi ro.
